import React from 'react';
import { Link } from 'react-router-dom';

const ErrorPageContent = () => {

 
    return (
        <div>
           
            <Link to="/"><p className='hyper-link'>Back to Order Page</p></Link>
        </div>
    );
};

export default ErrorPageContent;